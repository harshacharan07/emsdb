﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMSEntity;
using EMSException;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EMSDAL
{
    public class UserDAL
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection(ConnectionString);
        SqlCommand command;
        public bool GetUserPassword(UserEntity user)
        {
            bool IsPasswordMatch = false;

            try
            {
                string query = "usp_UserLogin";
                command = new SqlCommand(query, connection);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Clear();

                command.Parameters.AddWithValue("@UserName", user.UserName);
                command.Parameters.AddWithValue("@UserType", user.UserType);

                connection.Open();
                object RetrievedPassword = command.ExecuteScalar();

                if (RetrievedPassword != null && RetrievedPassword.ToString() == user.Password)
                {
                    IsPasswordMatch = true;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (EMSException.EMSException Exception)
            {
                throw Exception;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return IsPasswordMatch;
        }


    }
}
