﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EMSBLL;
using EMSException;
using EMSEntity;
using System.Data;

namespace EMSPL
{
    /// <summary>
    /// Interaction logic for Designation.xaml
    /// </summary>
    public partial class Designation : Page
    {
        public Designation()
        {
            InitializeComponent();
        }
        AdminBLL adminBLL = new AdminBLL();
        private void Btn_Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool Added = false;
                DesignationEntity designation = new DesignationEntity();

                designation.DesignationName = txtDesigName.Text;

                Added = adminBLL.AddDesignationBLL(designation);
                if (Added == true)
                {
                    MessageBox.Show("Added Successfully");
                    //LoadGrid();

                }
                else
                    MessageBox.Show("Not Added");
            }
            catch (EMSException.EMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter required fields");
            }
        }

        //public void LoadGrid()
        //{
        //    DataTable table = adminBLL.ViewAllDesignationBLL();
        //    datagrid.DataContext = table;
        //}

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Resources["username"] == null)
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }
            else
            {
                //LoadGrid();
            }

        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void Btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int designationId = int.Parse(txtDesigId.Text);
                bool deleteDesignation = adminBLL.DeleteDesignationBLL(designationId);
                if (deleteDesignation)
                {
                    MessageBox.Show("Deleted successfully");
                    //LoadGrid();
                }
                else
                {
                    MessageBox.Show("Something Went Wrong");
                }
            }
            catch (EMSException.EMSException fe)
            {
                MessageBox.Show(fe.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please Enter the designation Id");
            }
        }
    }
}
