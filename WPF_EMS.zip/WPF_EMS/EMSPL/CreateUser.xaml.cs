﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EMSException;
using EMSEntity;
using EMSBLL;
using System.Data.SqlClient;

namespace EMSPL
{
    /// <summary>
    /// Interaction logic for CreateUser.xaml
    /// </summary>
    public partial class CreateUser : Page
    {
        public CreateUser()
        {
            InitializeComponent();
        }
        AdminBLL adminBLL = new AdminBLL();
        private void Btn_Create_Click(object sender, RoutedEventArgs e)
        {
            if (AddUserPL() == true)
            {
                MessageBox.Show(" User Added Successfully");
            }
            else
            {
                MessageBox.Show("Failed to Add User");

            }
        }

        private bool AddUserPL()
        {
            bool isAdded = false;
            try
            {
                UserEntity user = new UserEntity();
                user.UserName = txtUsername.Text;
                user.UserType = ((ComboBoxItem)CbUserType.SelectedItem).Content.ToString();
                user.Password = txtPassword.Password.ToString();
                isAdded = adminBLL.AddUser(user);
            }
            catch (SqlException Exception)
            {
                MessageBox.Show(Exception.Message.ToString());

            }
            catch (EMSException.EMSException Exception)
            {
                MessageBox.Show(Exception.Message);
            }
            catch (Exception Exception)
            {
                MessageBox.Show("Please enter required fields");
            }
            return isAdded;
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Resources["username"] == null)
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }

        }
    }
}
