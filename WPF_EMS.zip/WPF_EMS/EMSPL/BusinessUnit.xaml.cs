﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EMSBLL;
using EMSEntity;
using EMSException;
using System.Data;


namespace EMSPL
{
    /// <summary>
    /// Interaction logic for BusinessUnit.xaml
    /// </summary>
    public partial class BusinessUnit : Page
    {
        public BusinessUnit()
        {
            InitializeComponent();
        }

        AdminBLL adminBLL = new AdminBLL();

        private void Btn_Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool Added = false;
                BU_Entity bUnit = new BU_Entity();

                bUnit.BU_Name = txtBU_Name.Text;

                Added = adminBLL.AddBusinessUnitBLL(bUnit);
                if (Added == true)
                {
                    MessageBox.Show("Added Successfully");
                    //LoadGrid();

                }
                else
                    MessageBox.Show("Not Added");
            }
            catch (EMSException.EMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter required fields");
            }
        }


        //public void LoadGrid()
        //{
        //    DataTable table = adminBLL.ViewAllBusinessUnitBLL();
        //    datagrid.DataContext = table;
        //}


        private void Btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int businessUnitID = int.Parse(txtBU_Id.Text);
                bool deleteBusinessUnit = adminBLL.DeleteBusinessUnitBLL(businessUnitID);
                if (deleteBusinessUnit)
                {
                    MessageBox.Show("Deleted successfully");
                    //LoadGrid();
                }
                else
                {
                    MessageBox.Show("Something Went Wrong");
                }
            }
            catch (EMSException.EMSException fe)
            {
                MessageBox.Show(fe.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please Enter the Business Unit Id");
            }
        }
    }
}
